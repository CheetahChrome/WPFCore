﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WPFCore3
{
    class LogInfo
    {
        public DateTime Date { get; set; }
        public string Info { get; set; }


    }
}
